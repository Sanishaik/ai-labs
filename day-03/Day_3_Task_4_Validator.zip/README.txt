Day 3 - Task 4: JSON Validator

Files:
- validate.py: checks required fields, date format, GSTIN length and amount type.
- valid_invoice.json: sample valid invoice.
- broken_1_missing_field.json: missing invoice_no.
- broken_2_invalid_date.json: invoice_date is not YYYY-MM-DD.
- broken_3_invalid_gstin.json: GSTIN is not 15 characters.

Run in a terminal from this folder:
python validate.py valid_invoice.json broken_1_missing_field.json broken_2_invalid_date.json broken_3_invalid_gstin.json

Expected: 1 passed and 3 failed.
