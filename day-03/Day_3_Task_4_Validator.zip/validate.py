import json
import re
import sys
from datetime import datetime
from pathlib import Path

REQUIRED_FIELDS = {
    "vendor_name",
    "invoice_no",
    "invoice_date",
    "gstin",
    "po_number",
    "amount",
    "due_date",
}

DATE_FIELDS = {"invoice_date", "due_date"}
GSTIN_PATTERN = re.compile(r"^[A-Za-z0-9]{15}$")


def validate_invoice(file_path):
    errors = []

    try:
        with open(file_path, "r", encoding="utf-8") as file:
            data = json.load(file)
    except json.JSONDecodeError as error:
        return [f"Invalid JSON syntax: {error.msg} (line {error.lineno})"]
    except OSError as error:
        return [f"Could not read file: {error}"]

    if not isinstance(data, dict):
        return ["JSON must contain one invoice object."]

    missing = REQUIRED_FIELDS - data.keys()
    if missing:
        errors.append("Missing required fields: " + ", ".join(sorted(missing)))

    for field in DATE_FIELDS:
        value = data.get(field)
        if value is not None:
            try:
                datetime.strptime(value, "%Y-%m-%d")
            except (ValueError, TypeError):
                errors.append(f"{field} must be a valid date in YYYY-MM-DD format.")

    gstin = data.get("gstin")
    if gstin is not None:
        if not isinstance(gstin, str) or not GSTIN_PATTERN.fullmatch(gstin):
            errors.append("gstin must contain exactly 15 letters/numbers, or be null.")

    amount = data.get("amount")
    if amount is not None and (isinstance(amount, bool) or not isinstance(amount, (int, float))):
        errors.append("amount must be a number.")

    for field in ("vendor_name", "invoice_no"):
        value = data.get(field)
        if value is not None and (not isinstance(value, str) or not value.strip()):
            errors.append(f"{field} must be a non-empty string.")

    return errors


def main():
    files = sys.argv[1:] or [str(path) for path in Path(".").glob("*.json")]
    if not files:
        print("No JSON files found. Provide JSON filenames as arguments.")
        return

    passed = 0
    failed = 0

    for filename in files:
        errors = validate_invoice(filename)
        if errors:
            failed += 1
            print(f"\nFAIL: {filename}")
            for error in errors:
                print(f"  - {error}")
        else:
            passed += 1
            print(f"\nPASS: {filename} - all checks passed")

    print("\nVALIDATION SUMMARY")
    print(f"Passed: {passed}")
    print(f"Failed: {failed}")
    print(f"Total:  {passed + failed}")


if __name__ == "__main__":
    main()
